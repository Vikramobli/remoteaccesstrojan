# Keylogger-C
A simple C keylogger

Use under your own responsability.

Download [here](https://github.com/LNDF/Keylogger-C/releases)

## How to use

1. Download the keylogger. Select one of the binaries.
    * **console**: This binary opens a console so you can test the keylogger. Close the console to kill the keylogger.
    * **no_gui**: This will not open any window and work in the background.
2. Place the keyboard whatever you want.
3. Start the keyboard. It will create a folder named ***logs***- Inside that folder it will create txt documents with the log.

## Features

* Logs the focused window title.
* If the user left or right clicks the mouse the log will jump to the next line.
* Most of the key combinations supported.
* Most of the keyboard layouts supported (I belive, I haven't tested it in every keyboard layout).
* CPU and RAM friendly (0-2% CPU, 500 KB RAM).

## Credits

All the credits are for LNDF
